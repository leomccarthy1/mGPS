* `Dataset_01_22_2018_enviro.csv` - Soil origin metadata
* `Dataset_01_22_2018_taxa.csv` - Soil OTU taxa read data
* `complete_metadata.csv` - MetaSUB enrionnmental and geo data
* `metasub_taxa_abundance.csv` - MetaSUB taxa abundance data
* `opt_taxa_metasub.csv` - Optimal 200 species for global MetaSUB predictions
* `opt_taxa_soil.csv` - Optimal 200 OTU taxa for global soil preidctions
* `msub_meta_taxa.csv` - metasub abundance and origin metadata cleaned, combined by sample ID
